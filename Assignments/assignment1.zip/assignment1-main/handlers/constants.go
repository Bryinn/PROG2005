package handlers

import "time"

/**
* Constants
 */
const LINEBREAK = "\n"
const DEBUG = false
const COUNTRIES_NOW_API = "http://129.241.150.113:3500/api/v0.1"
const REST_COUNTIRES_API = "http://129.241.150.113:8080/v3.1/alpha"

var startTime = time.Now()
